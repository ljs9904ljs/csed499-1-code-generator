
// simple.c file
// #include <stdio.h>


void print_hello(int a, int b) {
    printf("print hello world. junseok lee.");
    printf("a + b = %d", a + b);
    return;
}
int main (int argc, char** argv) {

    print_hello(argv[1], argv[2]);

    return 0;
}
